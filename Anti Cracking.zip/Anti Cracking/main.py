from gui import main
import tkinter as tk

if __name__ == "__main__":
    main()