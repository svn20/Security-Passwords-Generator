'''
Este modulo almacena todos los posibles colores a 
implementar

'''

c_negro = "#010101"
c_amarillo = "#F6BB43"
c_purple = "#427EF6"
c_rojo = "#FF0000"
c_verde = "#00FF00"
c_magenta = "#FF00FF"
c_cyan = "#00FFFF"
c_naranja = "#FFA500"
c_rosa = "#FFC0CB"
c_purple = "#800080"
c_oliva = "#808000"
c_gris = "#808080"
c_teal = "#008080"
c_blanco = "#FFFFFF"
c_violeta = "#EE82EE"
c_oro = "#FFD700"
c_plata = "#C0C0C0"
c_bronce = "#CD7F32"
c_granate = "#800000"